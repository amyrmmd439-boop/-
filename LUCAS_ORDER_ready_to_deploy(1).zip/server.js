const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const bcrypt = require("bcryptjs");
const { createClient } = require("@libsql/client");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const SESSION_SECRET = process.env.SESSION_SECRET;
const TURSO_DATABASE_URL = process.env.TURSO_DATABASE_URL;
const TURSO_AUTH_TOKEN = process.env.TURSO_AUTH_TOKEN;

if (!ADMIN_PASSWORD || !SESSION_SECRET || !TURSO_DATABASE_URL || !TURSO_AUTH_TOKEN) {
  console.error("Missing required environment variables.");
  process.exit(1);
}

const db = createClient({ url: TURSO_DATABASE_URL, authToken: TURSO_AUTH_TOKEN });
const adminHash = bcrypt.hashSync(ADMIN_PASSWORD, 12);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "30kb" }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: "auto", maxAge: 8 * 60 * 60 * 1000 }
}));
app.use(express.static("public"));

async function initDb() {
  await db.execute(`CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer TEXT NOT NULL,
    contact TEXT NOT NULL,
    product TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    amount TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'جدید',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  )`);
}
const requireAdmin = (req, res, next) => req.session.isAdmin ? next() : res.status(401).json({ error: "ابتدا وارد پنل مدیریت شوید." });

app.post("/api/orders", async (req, res) => {
  try {
    const { customer, contact, product, quantity, amount, notes } = req.body || {};
    if (![customer, contact, product].every(v => typeof v === "string" && v.trim()) ||
        !Number.isInteger(Number(quantity)) || Number(quantity) < 1) {
      return res.status(400).json({ error: "لطفاً نام، راه ارتباطی، محصول و تعداد معتبر وارد کنید." });
    }
    await db.execute({
      sql: "INSERT INTO orders (customer, contact, product, quantity, amount, notes) VALUES (?, ?, ?, ?, ?, ?)",
      args: [customer.trim().slice(0,100), contact.trim().slice(0,100), product.trim().slice(0,150),
        Number(quantity), String(amount || "").slice(0,50), String(notes || "").slice(0,1000)]
    });
    res.json({ ok: true, message: "سفارش شما ثبت شد." });
  } catch (e) { console.error(e); res.status(500).json({ error: "ثبت سفارش انجام نشد. دوباره تلاش کنید." }); }
});

app.post("/api/login", (req, res) => {
  const password = String((req.body || {}).password || "");
  if (!bcrypt.compareSync(password, adminHash)) return res.status(401).json({ error: "رمز عبور درست نیست." });
  req.session.isAdmin = true;
  res.json({ ok: true });
});
app.post("/api/logout", (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get("/api/orders", requireAdmin, async (req, res) => {
  try {
    const result = await db.execute("SELECT * FROM orders ORDER BY id DESC LIMIT 500");
    res.json(result.rows);
  } catch (e) { console.error(e); res.status(500).json({ error: "دریافت سفارش‌ها انجام نشد." }); }
});
app.patch("/api/orders/:id", requireAdmin, async (req, res) => {
  const status = String((req.body || {}).status || "");
  if (!["جدید", "در حال انجام", "تکمیل شد", "لغو شد"].includes(status)) return res.status(400).json({ error: "وضعیت نامعتبر است." });
  try {
    await db.execute({ sql: "UPDATE orders SET status = ? WHERE id = ?", args: [status, Number(req.params.id)] });
    res.json({ ok: true });
  } catch (e) { console.error(e); res.status(500).json({ error: "به‌روزرسانی انجام نشد." }); }
});
app.get("/health", (_req, res) => res.send("ok"));

initDb().then(() => app.listen(PORT, () => console.log(`Lucas Order running on ${PORT}`)))
  .catch(e => { console.error("Database initialization failed", e); process.exit(1); });
